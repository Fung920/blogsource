<!DOCTYPE html>
<html>
<body>

<style type="text/css">
body {background-color:#CCCCCC; text-align:center; }
</style>

<iframe src="login.php" width="950" height="620" marginwidth="5" marginheight="2" hspace="2" vspace="2" border="2" frameborder="2" scrolling="auto" >
  <p>Your browser does not support iframes.</p>
</iframe>

</body>
</html>
