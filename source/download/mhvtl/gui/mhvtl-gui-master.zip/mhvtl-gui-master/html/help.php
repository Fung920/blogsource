<html>
<head><title>MHVTL</title></head>
<link href="styles.css" rel="stylesheet" type="text/css">
<body>
<hr width="100%" size=10 color="blue">
<b><font color=purple size=3>MHVTL Support</font></b>
<hr width="100%" size=1 color="blue">


<tr>
<td>
<img src="images/help.png" >
</td>
</tr>

<?php
echo "<pre><b> Support :</b></pre>";
?>


<table border="0" >


<tr>
<td>
<a href="#" input class="sameLook" style="color: #0000FF" ONCLICK="parent.frames[1].location.href='http://mhvtl-community-forums.966029.n3.nabble.com/'" target="showframe">Support Forums </a>
</td>
</tr>


<tr>
<td>
<a href="#" input class="sameLook" style="color: #FF0000" ONCLICK="parent.frames[1].location.href='http://sites.google.com/site/linuxvtl2/'" target="showframe">MHVTL Development Web Site </a>
</td>
</tr>



<tr>
<td>
<a href="#" input class="sameLook" style="color: #000000" ONCLICK="parent.frames[1].location.href='about.php'" target="showframe">About MHVTL
</td>
</tr>

<tr>
<td>
<a href="#" input class="sameLook" style="color: #000000" ONCLICK="parent.frames[1].location.href='about_console.php'" target="showframe">About MHVTL Console
</td>
</tr>


<tr>
<td>
<a href="#" input class="sameLook" style="color: #000000" ONCLICK="parent.frames[1].location.href='http://stgt.sourceforge.net'" target="showframe">About iSCSI Target (tgt)
</td>
</tr>


<tr>
<td>
<a href="#" input class="sameLook" style="color: #008000" ONCLICK="parent.frames[1].location.href='sendfeedback.php'" target="showframe">Send Feedback (MHVTL Console)
</td>
</tr>


</table>


</body>
</html>
