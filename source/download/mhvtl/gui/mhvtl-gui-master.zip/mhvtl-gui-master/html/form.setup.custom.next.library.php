<html>
<head><title>MHVTL</title></head>
<link href="styles.css" rel="stylesheet" type="text/css">
<body>
<hr width="100%" size=10 color="blue">
<b>MHVTL Configuration</b><br>
<hr width="100%" size=1 color="blue">

<tr>
<td align=left valign=middle>
<img src="images/configuration.png" >
</td>
</tr>

<?php
echo "<pre><b>Create Custom Library :</b></pre>";
?>



<TABLE BORDER=1 CELLSPACING=4 CELLPADDING=4 align="left" valign="middle" >
<TR>
<TD>
<br>
<br>
This wizard will guide you to create custom library, drives and media
<br>
<br>
<FORM ACTION="setup.php"><INPUT TYPE=SUBMIT VALUE="Return"><INPUT TYPE="button" VALUE="Next" input ONCLICK="parent.frames[1].location.href='form.add.custom.complete.php'" target="showframe">
</FORM>
</td>
</tr>
</table>


</body>
</html>
