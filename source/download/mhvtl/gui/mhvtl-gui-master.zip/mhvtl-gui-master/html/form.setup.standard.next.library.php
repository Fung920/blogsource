<html>
<head><title>MHVTL</title></head>
<link href="styles.css" rel="stylesheet" type="text/css">
<body>
<hr width="100%" size=10 color="blue">
<b><font color=purple size=3>MHVTL Settings</font><b>
<hr width="100%" size=1 color="blue">

<tr>
<td align=left valign=middle>
<img src="images/configuration.png" >
</td>
</tr>

<?php
echo "<pre><b>Standard configuration type :</b></pre>";
?>

<TABLE BORDER=0>

<TABLE BORDER=1 CELLSPACING=4 CELLPADDING=4 align="left" valign="middle" >
<TR>
<TD>
<br>
<br>
This wizard will guide you to create standard library, drives and media
<br>
<br>
<FORM ACTION="form.setup.complete.php"><INPUT TYPE=SUBMIT VALUE="Return"><INPUT TYPE="button" VALUE="Next" input ONCLICK="parent.frames[1].location.href='form.setup.choose.standard.complete.php'" target="showframe">
</FORM>
</td>
</tr>
</table>
</table>

</body>
</html>
