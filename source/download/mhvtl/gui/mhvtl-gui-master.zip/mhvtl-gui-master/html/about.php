<html>
<head><title>MHVTL</title></head>
<link href="styles.css" rel="stylesheet" type="text/css">
<body>
<hr width="100%" size=10 color="blue">
<b><font color=purple size=3>MHVTL Support</font></b>
<hr width="100%" size=1 color="blue">


<tr>
<td align=left valign=middle>
<img src="images/about.png" >
</td>
</tr>

<?php
echo "<pre><b>About MHVTL :</b></pre>";
?>


<table border="0" align="left" valign="middle" >


<tr>
<td>
<pre><img src="images/tab_right.png" ALIGN="middle" ><a href="#" ONCLICK="parent.frames[1].location.href='http://sites.google.com/site/linuxvtl2/'" target="showframe"> MHVTL - Linux Virtual Tape Library Developed by Mark Harvey (markh794@gmail.com)</pre>
</td>
</tr>


<tr>
<td>
<pre><img src="images/tab_right.png" ALIGN="middle" ><a href="#" ONCLICK="parent.frames[1].location.href='http://www.gnu.org/licenses/gpl-2.0.html'" target="showframe"> GNU GENERAL PUBLIC LICENSE : GPL v2 : Copyright (C) 2011. All rights reserved.</pre>
</td>
</tr>


</table>

</body>
</html>
