<html>
<head><title>MHVTL</title></head>
<link href="styles.css" rel="stylesheet" type="text/css">
<body>
<hr width="100%" size=10 color="blue">
<b><font color=purple size=3>Misc Tools</font><b>
<hr width="100%" size=1 color="blue">


<tr>
<td align=left valign=middle>
<img src="images/operation.png" >
</td>
</tr>

<?php
echo "<pre><b>Empty :</b></pre>";
?>

<hr width="100%" size=1 color="blue">

This function is currently not implemented

<hr width="100%" size=1 color="blue">
<br>
<FORM ACTION="tools.php"><INPUT TYPE=SUBMIT VALUE="Return"></FORM>

</body>
</html>
