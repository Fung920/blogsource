<html>
<head><title>MHVTL</title></head>
<link href="styles.css" rel="stylesheet" type="text/css">
<body>
<hr width="100%" size=10 color="blue">
<b><font color=purple size=3>SCST - GENERIC SCSI TARGET SUBSYSTEM FOR LINUX</font></b>
<hr width="100%" size=1 color="blue">


<tr>
<td align=left valign=middle>
<img src="images/scsi_target.png" >
</td>
</tr>

<?php
echo "<pre><b>For Future Use :</b></pre>";
?>



<TABLE BORDER=4 CELLSPACING=4 CELLPADDING=4 align="left" valign="middle" >
<TR>
<TD>
<br>
<br>
This feature is currently not supported. It will be included in the upcoming releases..
<br>
<br>
<INPUT TYPE="button" VALUE="Return" input ONCLICK="parent.frames[1].location.href='scsi_target.php'" target="showframe">
</FORM>
</td>
</tr>
</table>


</body>
</html>
